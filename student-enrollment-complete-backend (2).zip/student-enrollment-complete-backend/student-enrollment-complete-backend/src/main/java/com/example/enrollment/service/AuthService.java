package com.example.enrollment.service;
import com.example.enrollment.model.Student;
import com.example.enrollment.repository.StudentRepository;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.Date;
@Service
public class AuthService {
    private final StudentRepository studentRepository;
    @Value("${jwt.secret}")
    private String secret;
    public AuthService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }
    public String login(String email, String password) {
        Student student = studentRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
        if (!student.getPassword().equals(password)) throw new RuntimeException("Invalid credentials");
        return Jwts.builder().setSubject(email).setIssuedAt(new Date()).signWith(SignatureAlgorithm.HS256, secret).compact();
    }
}