package com.example.enrollment.controller;
import com.example.enrollment.model.Enrollment;
import com.example.enrollment.repository.EnrollmentRepository;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/enroll")
public class EnrollmentController {
    private final EnrollmentRepository enrollmentRepository;
    public EnrollmentController(EnrollmentRepository enrollmentRepository) { this.enrollmentRepository = enrollmentRepository; }
    @PostMapping
    public Enrollment enroll(@RequestBody Enrollment enrollment) { return enrollmentRepository.save(enrollment); }
}